package com.horizontal.launcher

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF090D18)
private val Panel = Color(0xFF141C2D)
private val Accent = Color(0xFF6C8CFF)
private val Muted = Color(0xFF9AA8C2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { HorizontalApp() }
    }
}

@Composable
fun HorizontalApp() {
    var page by remember { mutableStateOf("Home") }
    var version by remember { mutableStateOf("1.21.11") }
    var showVersions by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Accent,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Row(Modifier.fillMaxSize().background(Bg)) {
            NavigationRail(page = page, onSelect = { page = it })
            Box(Modifier.weight(1f).fillMaxHeight()) {
                when (page) {
                    "Home" -> HomeScreen(version, { showVersions = true }, { page = "Downloads" })
                    "Versions" -> VersionsScreen(version) { version = it }
                    "Mods" -> SimpleScreen("Mod Manager", "Your installed mods will appear here.", listOf("Mods folder", "Install mod", "Refresh list"))
                    "Downloads" -> SimpleScreen("Downloads", "Download progress and game files will appear here.", listOf("Game files", "Libraries", "Java runtime"))
                    "Settings" -> SimpleScreen("Settings", "Launcher preferences.", listOf("Memory allocation", "Resolution", "Performance options", "About Horizontal"))
                }
                if (showVersions) {
                    AlertDialog(
                        onDismissRequest = { showVersions = false },
                        title = { Text("Select version") },
                        text = {
                            Column {
                                listOf("1.21.11", "1.21.10", "1.21.8", "1.20.1").forEach {
                                    Text(it, Modifier.fillMaxWidth().clickable {
                                        version = it; showVersions = false
                                    }.padding(12.dp))
                                }
                            }
                        },
                        confirmButton = { TextButton(onClick = { showVersions = false }) { Text("Close") } }
                    )
                }
            }
        }
    }
}

@Composable
fun NavigationRail(page: String, onSelect: (String) -> Unit) {
    Column(
        Modifier.width(76.dp).fillMaxHeight().background(Color(0xFF0D1423)).padding(vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(Modifier.size(46.dp).background(Accent.copy(alpha = .18f), CircleShape), contentAlignment = Alignment.Center) {
            Text("↔", color = Accent, fontSize = 27.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        listOf("Home", "Versions", "Mods", "Downloads", "Settings").forEach { item ->
            val selected = page == item
            Column(
                Modifier.fillMaxWidth().clickable { onSelect(item) }.padding(vertical = 9.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    when(item) { "Home" -> "⌂"; "Versions" -> "◫"; "Mods" -> "▦"; "Downloads" -> "↓"; else -> "⚙" },
                    color = if (selected) Accent else Muted, fontSize = 22.sp
                )
                Text(item, color = if (selected) Color.White else Muted, fontSize = 9.sp)
            }
        }
    }
}

@Composable
fun HomeScreen(version: String, onVersions: () -> Unit, onDownloads: () -> Unit) {
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 22.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Spacer(Modifier.height(22.dp))
            Text("HORIZONTAL", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("Your Minecraft,\nyour way.", color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 36.sp)
            Text("JAVA EDITION  •  ANDROID", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        }
        item {
            Box(
                Modifier.fillMaxWidth().height(185.dp)
                    .background(Brush.linearGradient(listOf(Color(0xFF263C73), Color(0xFF17233C), Color(0xFF101827))), RoundedCornerShape(22.dp))
                    .padding(20.dp)
            ) {
                Column(Modifier.align(Alignment.BottomStart)) {
                    Text("READY TO PLAY?", color = Color(0xFFB9C9FF), fontSize = 11.sp, letterSpacing = 2.sp)
                    Text("Minecraft Java", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("Launcher preview • Game engine not connected yet", color = Muted, fontSize = 10.sp)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(17.dp)) {
                    Text("SELECTED VERSION", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text(version, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                        OutlinedButton(onClick = onVersions) { Text("Change") }
                    }
                }
            }
        }
        item {
            Button(
                onClick = onDownloads,
                modifier = Modifier.fillMaxWidth().height(58.dp),
                shape = RoundedCornerShape(16.dp)
            ) { Text("PREPARE GAME  →", fontWeight = FontWeight.Bold, letterSpacing = 1.sp) }
        }
        item {
            Text("QUICK ACCESS", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickCard("MODS", "Manage add-ons", Modifier.weight(1f))
                QuickCard("PERFORMANCE", "Tune settings", Modifier.weight(1f))
            }
        }
        item {
            Text("STATUS: UI PREVIEW", color = Color(0xFFFFC66D), fontSize = 11.sp)
            Text("Minecraft downloading, account login, Java runtime and game launching are not connected in this first build.", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(22.dp))
        }
    }
}

@Composable
fun QuickCard(title: String, subtitle: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Text(title, color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text(subtitle, color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
fun VersionsScreen(selected: String, onChoose: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Versions", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text("Choose a Minecraft version for your profile.", color = Muted)
        listOf("1.21.11", "1.21.10", "1.21.8", "1.20.1").forEach { v ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth().clickable { onChoose(v) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(v, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Text(if (v == selected) "SELECTED" else "SELECT", color = if (v == selected) Accent else Muted, fontSize = 10.sp)
                }
            }
        }
        Text("Preview only: version metadata and game files are not downloaded yet.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun SimpleScreen(title: String, subtitle: String, rows: List<String>) {
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted)
        rows.forEach { row ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                Text(row, Modifier.padding(18.dp), fontWeight = FontWeight.Medium)
            }
        }
        Text("This section is a UI placeholder in version 0.1.0.", color = Muted, fontSize = 11.sp)
    }
}
