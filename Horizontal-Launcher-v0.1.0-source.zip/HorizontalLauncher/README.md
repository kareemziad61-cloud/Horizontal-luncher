# Horizontal Launcher — v0.1.0 UI starter

This is an Android Studio Kotlin + Jetpack Compose project.

## What works
- Main launcher screen
- Side navigation
- Version selector UI (sample versions only)
- Mods, Downloads, and Settings placeholder screens
- Horizontal two-arrow branding mark

## Not implemented yet
This is NOT yet a functioning Minecraft launcher. It does not download Minecraft,
authenticate accounts, install Java/Fabric/Forge, manage real mod files, or start the game.
Those systems require additional implementation and testing.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Connect an Android device or start an emulator.
4. Choose Run, or use Build > Build APK(s).

Requires JDK 17 and Android SDK platform 35. Gradle wrapper is not included;
Android Studio can create/use its compatible Gradle installation.
